package FirstExample;

public interface Vehicle {

    void setLocation(int location);
    void setAvailability(boolean availability);
}
