package FirstExample;

public class Scooter implements Vehicle {

    private int location;
    private boolean availability;
    private int charge = 100;


    @Override
    public void setLocation(int location) {

    }

    @Override
    public void setAvailability(boolean availability) {

    }


}
