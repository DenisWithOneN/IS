package FirstExample;

public interface IClient {

    void setLocation(int location);
    void requestDrive();
}
