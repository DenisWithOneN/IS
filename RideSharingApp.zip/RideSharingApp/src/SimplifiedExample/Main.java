package SimplifiedExample;

import java.util.List;

public class Main {

    public static void main(String[] args) {

        Car car1 = new Car(1, 1);
        car1.setAvailability(true);
        Car car2 = new Car(2, 2);
        car2.setAvailability(true);
        Car car3 = new Car(3, 3);
        car3.setAvailability(false);
        Car car4 = new Car(4, 4);
        car4.setAvailability(true);

    }
}
