package SimplifiedExample;

public class Customer {

    private int customerID;
    private int location;

    public Customer(int customerID, int location) {
        this.customerID = customerID;
        this.location = location;
    }


}
