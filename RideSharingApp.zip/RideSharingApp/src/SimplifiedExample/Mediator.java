package SimplifiedExample;

public class Mediator {


}
